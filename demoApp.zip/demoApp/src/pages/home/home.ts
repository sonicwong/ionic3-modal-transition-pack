import { Component } from '@angular/core';
import { NavController, ModalController, ViewController } from 'ionic-angular';
import { TestModalContentPage } from './testmodal';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

    private testmodal;
    
  constructor(public navCtrl: NavController, private modalCtrl: ModalController) {

  }

    /* ===========================
    page event
    =========================== */
    ionViewDidEnter(){
        console.log('page enter');
        
        
    }
    
    openModal(enterAni, leaveAni) {
        this.testmodal = this.modalCtrl.create(TestModalContentPage, {}, {
            showBackdrop: true
            ,enableBackdropDismiss: false
            ,enterAnimation: enterAni
            ,leaveAnimation: leaveAni
        });
        this.testmodal.onDidDismiss(data => {
            console.log('modal.onDidDismiss');
        });
        this.testmodal.present();
    }
}

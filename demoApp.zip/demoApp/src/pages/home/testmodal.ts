import { Component } from '@angular/core';
import { ViewController } from 'ionic-angular';

@Component({
    templateUrl: 'testmodal.html',
})

export class TestModalContentPage {
    constructor(
        public viewCtrl: ViewController
    ) {
            
    }
    public dismiss() {
        this.viewCtrl.dismiss();
    }
    
    ionViewDidEnter(){
        console.log('modal displaying...');
    }
}